import SwiftUI

@main
struct WildFocusApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

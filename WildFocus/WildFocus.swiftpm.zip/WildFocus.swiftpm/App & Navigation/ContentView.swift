import SwiftUI

struct ContentView: View {
    @StateObject var manager = GameManager()
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            Group {
                if manager.state == .camp || manager.state == .setup {
                    CampView(manager: manager)
                        .disabled(manager.state == .setup)
                } else if manager.state == .training {
                    ActiveTrainingView(manager: manager)
                } else if manager.state == .bestiary {
                    BestiaryView(manager: manager)
                } else {
                    BattlefieldView(manager: manager)
                }
            }
            .transition(.opacity)
            
            if manager.state == .setup {
                Color.black.opacity(0.6)
                    .ignoresSafeArea()
                    .onTapGesture { manager.cancelSetup() }
                    .transition(.opacity)
                    .zIndex(1)
                
                SetupHUDView(manager: manager)
                    .transition(.move(edge: .bottom))
                    .zIndex(2)
            } else if manager.state == .encounter {
                EncounterPopup(manager: manager)
                    .transition(.scale.combined(with: .opacity))
                    .zIndex(3)
            } else if manager.state == .rewards {
                RewardsPopup(manager: manager)
                    .transition(.move(edge: .bottom))
                    .zIndex(4)
            }
        }
        .animation(.spring(response: 0.4, dampingFraction: 0.8), value: manager.state)
    }
}

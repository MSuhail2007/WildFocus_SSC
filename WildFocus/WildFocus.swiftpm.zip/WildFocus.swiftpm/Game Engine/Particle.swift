import SwiftUI

struct Particle: Identifiable {
    let id = UUID()
    let randomX = CGFloat.random(in: -200...200)
    let randomSize = CGFloat.random(in: 4...12)
    let duration = Double.random(in: 4...8)
    let delay = Double.random(in: 0...2)
}

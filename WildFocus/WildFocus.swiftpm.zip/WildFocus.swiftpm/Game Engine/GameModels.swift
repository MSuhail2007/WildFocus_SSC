import SwiftUI
enum Biome {
    case forest, cave, volcano
    var imageName: String {
        switch self {
        case .forest: return "bg_forest"
        case .cave: return "bg_cave"
        case .volcano: return "bg_volcano"
        }
    }
}

enum FoxStage {
    case baby, toddler, teen, adult, awakened, godTier
    var imageName: String {
        switch self {
        case .baby: return "fox_lvl1"
        case .toddler: return "fox_lvl5"
        case .teen: return "fox_lvl10"
        case .adult: return "fox_lvl15"
        case .awakened: return "fox_lvl20"
        case .godTier: return "fox_lvl30"
        }
    }
}

enum EnemyTier {
    case spore, spider, bat, scorpion, condor, grizzly
    var imageName: String {
        switch self {
        case .spore: return "enemy_spore"
        case .spider: return "enemy_spider"
        case .bat: return "enemy_bat"
        case .scorpion: return "enemy_scorpion"
        case .condor: return "enemy_condor"
        case .grizzly: return "enemy_grizzly"
        }
    }
}

enum GameState {
    case camp, setup, training, encounter, enemyAppearing, battling, rewards, bestiary
}

import SwiftUI
import AVFoundation

@MainActor
class GameManager: ObservableObject {
    @Published var state: GameState = .camp
    
    @Published var petLevel: Int { didSet { UserDefaults.standard.set(petLevel, forKey: "petLevel") } }
    @Published var highestLevelReached: Int { didSet { UserDefaults.standard.set(highestLevelReached, forKey: "highestLevel") } }
    @Published var currentXP: Int { didSet { UserDefaults.standard.set(currentXP, forKey: "currentXP") } }
    @Published var xpNeededForNextLevel: Int { didSet { UserDefaults.standard.set(xpNeededForNextLevel, forKey: "xpNeeded") } }
    @Published var ascensionLevel: Int { didSet { UserDefaults.standard.set(ascensionLevel, forKey: "ascensionLevel") } }
    @Published var coins: Int { didSet { UserDefaults.standard.set(coins, forKey: "coins") } }
    @Published var petHealth: Int = 100
    let maxPetHealth: Int = 100
    

    @Published var selectedMinutes: Double = 25
    @Published var timeRemaining: Int = 0
    @Published var isTimerRunning: Bool = false
    @Published var isBattling: Bool = false
    @Published var didWin: Bool = false
    @Published var didFlee: Bool = false
    @Published var lastCoinsGained: Int = 0
    @Published var lastXPGained: Int = 0
    
    @Published var currentEnemyPower: Int = 0
    @Published var currentEnemyIsElite: Bool = false
    
    @Published var totalMonstersDefeated: Int { didSet { UserDefaults.standard.set(totalMonstersDefeated, forKey: "totalMonstersDefeated") } }
    @Published var totalFocusTimeMinutes: Int { didSet { UserDefaults.standard.set(totalFocusTimeMinutes, forKey: "totalFocusTimeMinutes") } }
    @Published var totalSessionsCompleted: Int { didSet { UserDefaults.standard.set(totalSessionsCompleted, forKey: "totalSessionsCompleted") } }
    
    var currentBiome: Biome {
        if petLevel >= 20 { return .volcano }
        if petLevel >= 10 { return .cave }
        return .forest
    }
    
    var currentPetImage: String {
        let prefix = ascensionLevel >= 1 ? "drake_lvl" : "fox_lvl"
        
        if petLevel >= 30 { return "\(prefix)30" }
        if petLevel >= 20 { return "\(prefix)20" }
        if petLevel >= 15 { return "\(prefix)15" }
        if petLevel >= 10 { return "\(prefix)10" }
        if petLevel >= 5 { return "\(prefix)5" }
        return "\(prefix)1"
    }
    
    var currentPetColor: Color {
        if ascensionLevel == 0 { return .cyan }
        if ascensionLevel == 1 { return .purple }
        return .yellow
    }
    
    var petName: String {
        if ascensionLevel == 0 { return "Spirit Fox" }
        if ascensionLevel == 1 { return "Obsidian Drake" }
        return "Astral Griffin"
    }
    
    var petPower: Int { (petLevel * 10) + (ascensionLevel * 500) }
    
    var currentEnemyImage: String {
        let index: Int
        if petLevel >= 30 { index = 5 }
        else if petLevel >= 20 { index = 4 }
        else if petLevel >= 15 { index = 3 }
        else if petLevel >= 10 { index = 2 }
        else if petLevel >= 5 { index = 1 }
        else { index = 0 }
        
        let baseNames = ["spore", "spider", "bat", "scorpion", "condor", "grizzly"]
        let prefix = currentEnemyIsElite ? "enemy_" : "wild_"
        return prefix + baseNames[index]
    }
    
    var currentEnemyColor: Color {
        if petLevel <= 10 { return .white }
        if petLevel <= 20 { return .green }
        return .purple
    }
    
    var currentEnemyTitle: String {
        let prefix = petLevel <= 10 ? "" : (petLevel <= 20 ? "Plague " : "Void ")
        let baseNames = ["Spore", "Spider", "Bat", "Scorpion", "Condor", "Grizzly"]
        
        let index: Int
        if petLevel >= 30 { index = 5 }
        else if petLevel >= 20 { index = 4 }
        else if petLevel >= 15 { index = 3 }
        else if petLevel >= 10 { index = 2 }
        else if petLevel >= 5 { index = 1 }
        else { index = 0 }
        
        let elitePrefix = currentEnemyIsElite ? "Elite " : ""
        return elitePrefix + prefix + baseNames[index]
    }
    
    init() {
        let defaults = UserDefaults.standard
        self.petLevel = defaults.integer(forKey: "petLevel") == 0 ? 1 : defaults.integer(forKey: "petLevel")
        self.highestLevelReached = defaults.integer(forKey: "highestLevel") == 0 ? 1 : defaults.integer(forKey: "highestLevel")
        self.ascensionLevel = defaults.integer(forKey: "ascensionLevel")
        self.currentXP = defaults.integer(forKey: "currentXP")
        self.xpNeededForNextLevel = defaults.integer(forKey: "xpNeeded") == 0 ? 100 : defaults.integer(forKey: "xpNeeded")
        self.coins = defaults.integer(forKey: "coins")
        
        self.totalMonstersDefeated = defaults.integer(forKey: "totalMonstersDefeated")
        self.totalFocusTimeMinutes = defaults.integer(forKey: "totalFocusTimeMinutes")
        self.totalSessionsCompleted = defaults.integer(forKey: "totalSessionsCompleted")
    }
    
    func startSetup() { withAnimation(.spring()) { state = .setup } }
    func cancelSetup() { withAnimation(.spring()) { state = .camp } }
    func openBestiary() { withAnimation(.spring()) { state = .bestiary } }
    func closeBestiary() { withAnimation(.spring()) { state = .camp } }
    
    func startTraining() {
        timeRemaining = Int(selectedMinutes * 60)
        withAnimation(.spring()) { state = .training }
    }
    
    func abortTraining() { withAnimation(.spring()) { state = .camp } }
    
    func completeFocusSession() { completeTraining() }
    
    func completeTraining() {
        currentEnemyIsElite = Bool.random()
        
        let eliteBonus = currentEnemyIsElite ? 15 : 0
        let normalEnemyPower = (petLevel * 12) + (ascensionLevel * 500) - 5 + eliteBonus
        
        if selectedMinutes >= 25 {
            currentEnemyPower = max(1, normalEnemyPower - Int.random(in: 15...25))
        } else if selectedMinutes >= 15 {
            currentEnemyPower = normalEnemyPower + Int.random(in: -5...5)
        } else {
            if Int.random(in: 1...100) <= 20 {
                currentEnemyPower = normalEnemyPower + Int.random(in: 30...50)
            } else {
                currentEnemyPower = normalEnemyPower
            }
        }
        
        totalFocusTimeMinutes += Int(selectedMinutes)
        totalSessionsCompleted += 1
        
        let impact = UINotificationFeedbackGenerator()
        impact.notificationOccurred(.warning)
        
        AudioServicesPlaySystemSound(1322)
        
        withAnimation(.spring()) { state = .encounter }
    }
    
    func ascend() {
        if ascensionLevel < 2 {
            withAnimation(.easeInOut(duration: 1.0)) {
                ascensionLevel += 1
                petLevel = 1
                currentXP = 0
                xpNeededForNextLevel = 100
                highestLevelReached = 1
                coins += 5000
            }
            let impact = UIImpactFeedbackGenerator(style: .heavy)
            impact.impactOccurred()
        }
    }
    
    func gainXP(amount: Int) {
        if petLevel >= 30 { return }
        withAnimation(.spring()) {
            currentXP += amount
            if currentXP >= xpNeededForNextLevel {
                petLevel += 1
                if petLevel > highestLevelReached { highestLevelReached = petLevel }
                if petLevel == 30 { currentXP = xpNeededForNextLevel }
                else { currentXP = 0; xpNeededForNextLevel += 35 }
                petHealth = maxPetHealth
            }
        }
    }
    
    func fightEnemy() {
        didFlee = false
        withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) { state = .enemyAppearing }
        
        Task {
            try? await Task.sleep(nanoseconds: 2_000_000_000)
            withAnimation(.spring()) { state = .battling }
            try? await Task.sleep(nanoseconds: 1_500_000_000)
            
            if petPower >= currentEnemyPower {
                didWin = true
                lastCoinsGained = Int.random(in: 30...80)
                coins += lastCoinsGained
                totalMonstersDefeated += 1
            } else {
                didWin = false
                lastCoinsGained = Int.random(in: 10...25)
                coins = max(0, coins - lastCoinsGained)
                petHealth = max(0, petHealth - 30)
            }
            
            try? await Task.sleep(nanoseconds: 1_500_000_000)
            withAnimation(.spring()) { state = .rewards }
        }
    }
    
    func fleeEncounter() {
        didFlee = true
        
        if petPower < currentEnemyPower {
            lastCoinsGained = Int.random(in: 15...30)
            coins += lastCoinsGained
        } else {
            lastCoinsGained = 0
        }
        
        withAnimation(.spring()) { state = .rewards }
    }
    
    func returnToCamp() { withAnimation(.spring()) { state = .camp } }
}

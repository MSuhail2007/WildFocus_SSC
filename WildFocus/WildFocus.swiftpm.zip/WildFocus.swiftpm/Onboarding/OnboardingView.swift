import SwiftUI

struct OnboardingView: View {
    @ObservedObject var manager: GameManager
    var onHatch: () -> Void
    @State private var currentPage = 0
    let pages: [OnboardingPageData] = [
        OnboardingPageData(
            title: "MEET YOUR SPIRIT",
            description: "Welcome to the Wilderness. This companion relies on your real-world focus to grow stronger.",
            imageName: "fox_lvl1",
            color: .cyan,
            isSystemImage: false
        ),
        OnboardingPageData(
            title: "DEEP WORK = XP",
            description: "Set the timer and put your phone down. The longer you study or work, the faster they level up.",
            imageName: "flame.fill",
            color: .orange,
            isSystemImage: true
        ),
        OnboardingPageData(
            title: "STAY DISCIPLINED",
            description: "If you abort the timer early, you will be ambushed and lose your hard-earned coins!",
            imageName: "wild_grizzly",
            color: .red,
            isSystemImage: false
        ),
        OnboardingPageData(
            title: "ASCEND TO LEGEND",
            description: "Reach Level 30 to prestige. Unlock God-Tier lineages like the Obsidian Drake.",
            imageName: "drake_lvl30",
            color: .purple,
            isSystemImage: false
        )
    ]
    
    var body: some View {
        GeometryReader { geo in
            let isPad = geo.size.width > 600
            
            ZStack {
                Color(white: 0.05).ignoresSafeArea()
                
                VStack(spacing: 0) {
                    HStack(spacing: 8) {
                        ForEach(0..<pages.count, id: \.self) { index in
                            Capsule()
                                .fill(currentPage == index ? pages[currentPage].color : Color.white.opacity(0.15))
                                .frame(width: currentPage == index ? 32 : 12, height: 6)
                                .animation(.spring(response: 0.4, dampingFraction: 0.7), value: currentPage)
                        }
                    }
                    .padding(.top, isPad ? 40 : 20)
                    .padding(.bottom, 20)
                    TabView(selection: $currentPage) {
                        ForEach(0..<pages.count, id: \.self) { index in
                            OnboardingPageView(page: pages[index], isPad: isPad)
                                .tag(index)
                        }
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))

                    ZStack {
                        if currentPage == pages.count - 1 {
                            Button(action: handleStart) {
                                HStack(spacing: 10) {
                                    Text("GET STARTED")
                                    Image(systemName: "sparkles")
                                }
                                .font(.system(size: isPad ? 22 : 18, weight: .black, design: .rounded))
                                .foregroundColor(.black)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, isPad ? 24 : 20)
                                .background(pages[currentPage].color)
                                .cornerRadius(isPad ? 40 : 30)
                                .shadow(color: pages[currentPage].color.opacity(0.4), radius: 15, y: 5)
                            }
                            .transition(.scale.combined(with: .opacity))
                        } else {
                            HStack(spacing: 8) {
                                Image(systemName: "chevron.left")
                                Text("SWIPE TO NAVIGATE")
                                    .tracking(2)
                                Image(systemName: "chevron.right")
                            }
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundColor(.white.opacity(0.3))
                            .transition(.opacity)
                        }
                    }
                    .animation(.spring(response: 0.4, dampingFraction: 0.8), value: currentPage)
                    .frame(height: 70) // Fixed height to prevent UI jump
                    .frame(maxWidth: 500) // iPad Layout Cap
                    .padding(.horizontal, isPad ? 40 : 30)
                    .padding(.bottom, isPad ? 60 : 40)
                    .padding(.top, 10)
                }
            }
        }
    }
    
    private func handleStart() {
        let success = UINotificationFeedbackGenerator()
        success.notificationOccurred(.success)
        onHatch()
    }
}

struct OnboardingPageView: View {
    let page: OnboardingPageData
    let isPad: Bool
    
    @State private var floatOffset: CGFloat = 10
    
    var body: some View {
        VStack(spacing: 0) {
            Spacer()
            
            ZStack {
                Circle()
                    .fill(
                        RadialGradient(colors: [page.color.opacity(0.3), .clear], center: .center, startRadius: 0, endRadius: isPad ? 200 : 150)
                    )
                    .frame(width: isPad ? 400 : 300, height: isPad ? 400 : 300)
                
                if page.isSystemImage {
                    Image(systemName: page.imageName)
                        .font(.system(size: isPad ? 120 : 90))
                        .foregroundColor(page.color)
                        .shadow(color: page.color.opacity(0.4), radius: 15, y: 10)
                } else {
                    if UIImage(named: page.imageName) != nil {
                        Image(page.imageName)
                            .resizable()
                            .scaledToFit()
                            .frame(height: isPad ? 280 : 200)
                            .shadow(color: Color.black.opacity(0.6), radius: 10, y: 10)
                    } else {
                        Image(systemName: "star.circle.fill")
                            .font(.system(size: isPad ? 120 : 90))
                            .foregroundColor(page.color)
                    }
                }
            }
            .offset(y: floatOffset)
            .onAppear {
                withAnimation(.easeInOut(duration: 2.5).repeatForever(autoreverses: true)) {
                    floatOffset = -10
                }
            }
            
            Spacer()

            VStack(spacing: 16) {
                Text(page.title)
                    .font(.custom("AvenirNext-Heavy", size: isPad ? 34 : 28))
                    .foregroundColor(.white)
                    .tracking(1.2)
                
                Text(page.description)
                    .font(.custom("AvenirNext-Bold", size: isPad ? 18 : 16))
                    .foregroundColor(.white.opacity(0.8))
                    .multilineTextAlignment(.center)
                    .lineSpacing(8)
                    .frame(maxWidth: isPad ? 450 : 320)
            }
            .padding(.bottom, 30)
        }
        .padding(.horizontal, 20)
    }
}

struct OnboardingPageData {
    let title: String
    let description: String
    let imageName: String
    let color: Color
    let isSystemImage: Bool
}

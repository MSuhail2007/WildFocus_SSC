//
//  ContentView 2.swift
//  LastStand
//
//  Created by Mohammed suhail on 16/02/2026.
//


import SwiftUI

struct ContentView: View {
    @State private var showIntro = true
    @StateObject var bunkerManager = BunkerManager()
    
    var body: some View {
        ZStack {
            if showIntro {
                IntroView(showIntro: $showIntro)
            } else {
                // If focusing, show the "Defense Screen", otherwise Dashboard
                if bunkerManager.isFocusing {
                    Text("FOCUSING... DEFENDING BUNKER")
                        .foregroundColor(.white)
                        .onTapGesture { bunkerManager.isFocusing = false } // Temp way to go back
                } else {
                    DashboardView(manager: bunkerManager)
                }
            }
        }
        .animation(.easeInOut(duration: 0.5), value: showIntro)
        .animation(.easeInOut(duration: 0.5), value: bunkerManager.isFocusing)
    }
}
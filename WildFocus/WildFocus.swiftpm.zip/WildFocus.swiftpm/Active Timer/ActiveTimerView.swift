
import SwiftUI
import AVFoundation

struct ActiveTrainingView: View {
    @ObservedObject var manager: GameManager
    
    @State private var isBreathing = false
    @State private var floatY: CGFloat = 0
    @State private var beamPulse: Double = 0.3
    @State private var particlesActive = false
    
    @State private var isTimerFinished = false
    @State private var isHolding = false
    
    @State private var isTransitioning = false
    @State private var beamWidth: CGFloat = 160
    @State private var shockwaveScale: CGFloat = 1.0
    @State private var shockwaveOpacity: Double = 0.0
    @State private var sceneDarkness: Double = 0.0
    @State private var shadowOffset: CGFloat = 2000
    @State private var typedText = ""
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                
                Image(manager.currentBiome.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()
                    .blur(radius: 40)
                    .overlay(Color.black.opacity(0.85 + sceneDarkness))
                    .ignoresSafeArea()
                
                LinearGradient(
                    colors: [manager.currentPetColor.opacity(0.0), manager.currentPetColor.opacity(beamPulse), manager.currentPetColor.opacity(0.0)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .frame(width: beamWidth, height: geo.size.height)
                .blur(radius: 25)
                .ignoresSafeArea()
                .blendMode(.screen)
                .opacity(beamWidth <= 0 ? 0 : 1)
                
                ForEach(0..<15, id: \.self) { _ in
                    Circle()
                        .fill(manager.currentPetColor.opacity(Double.random(in: 0.3...0.8)))
                        .frame(width: CGFloat.random(in: 3...8))
                        .position(x: geo.size.width / 2 + CGFloat.random(in: -70...70), y: particlesActive ? -100 : geo.size.height + 100)
                        .blur(radius: 1.5)
                        .animation(Animation.linear(duration: Double.random(in: 4...8)).repeatForever(autoreverses: false).delay(Double.random(in: 0...5)), value: particlesActive)
                }
                
                VStack {
                    Spacer()
                    
                    Image(manager.currentPetImage)
                        .resizable()
                        .scaledToFit()
                        .frame(width: geo.size.width * 0.45)
                        .offset(y: floatY)
                        .scaleEffect(isHolding ? 1.15 : (isBreathing ? 1.03 : 0.97), anchor: .bottom)
                        .shadow(color: manager.currentPetColor.opacity(isHolding ? 1.0 : (0.8 - sceneDarkness)), radius: isHolding ? 50 : 30, y: 15)
                        .onLongPressGesture(minimumDuration: 2.0, perform: {
                            if isTimerFinished && !isTransitioning {
                                startCinematicSequence(geo: geo)
                            }
                        }, onPressingChanged: { inProgress in
                            if isTimerFinished && !isTransitioning {
                                withAnimation(.easeOut(duration: inProgress ? 2.0 : 0.5)) {
                                    isHolding = inProgress
                                    beamWidth = inProgress ? geo.size.width * 0.8 : 160
                                    beamPulse = inProgress ? 1.8 : 0.7
                                }
                                if inProgress { UIImpactFeedbackGenerator(style: .medium).impactOccurred() }
                            }
                        })
                    
                    Spacer()
                    
                    VStack {
                        if !isTimerFinished {
                            VStack(spacing: 2) {
                                Text("ABSORBING AURA")
                                    .font(.system(size: 12, weight: .black, design: .rounded))
                                    .foregroundColor(manager.currentPetColor)
                                    .tracking(4)
                                
                                Text(timeString(from: manager.timeRemaining))
                                    .font(.system(size: 90, weight: .ultraLight, design: .rounded))
                                    .foregroundColor(.white)
                                    .shadow(color: manager.currentPetColor.opacity(0.5), radius: 20, y: 5)
                                
                                Text("DO NOT DISTURB")
                                    .font(.system(size: 10, weight: .bold, design: .rounded))
                                    .foregroundColor(.gray)
                                    .tracking(2)
                                    .padding(.top, 10)
                            }
                            .padding(.bottom, 50)
                            
                            Button(action: {
                                UINotificationFeedbackGenerator().notificationOccurred(.error)
                                manager.abortTraining()
                            }) {
                                HStack(spacing: 6) {
                                    Image(systemName: "square.fill").font(.system(size: 8))
                                    Text("ABORT").font(.system(size: 12, weight: .bold, design: .rounded)).tracking(2)
                                }
                                .foregroundColor(.white.opacity(0.4))
                                .padding(.horizontal, 24).padding(.vertical, 12)
                                .background(Color.white.opacity(0.05))
                                .clipShape(Capsule())
                            }
                            .padding(.bottom, 50)
                            
                        } else {
                            VStack(spacing: 15) {
                                Text("AURA SATURATED")
                                    .font(.system(size: 16, weight: .black, design: .rounded))
                                    .foregroundColor(manager.currentPetColor)
                                    .tracking(6)
                                
                                Text("PRESS & HOLD PET TO ABSORB")
                                    .font(.system(size: 22, weight: .black, design: .rounded))
                                    .foregroundColor(.white)
                                    .multilineTextAlignment(.center)
                                    .shadow(color: manager.currentPetColor.opacity(0.8), radius: 15)
                                    .scaleEffect(isBreathing ? 1.02 : 0.98)
                                    .opacity(isHolding ? 0.0 : 1.0)
                            }
                            .padding(.bottom, 80)
                        }
                    }
                    .opacity(isTransitioning ? 0 : 1)
                    .animation(.easeOut(duration: 0.5), value: isTransitioning)
                }
                .frame(width: geo.size.width, height: geo.size.height)
                
                Circle()
                    .fill(manager.currentPetColor)
                    .frame(width: 50, height: 50)
                    .scaleEffect(shockwaveScale)
                    .opacity(shockwaveOpacity)
                    .blendMode(.screen)
                    .ignoresSafeArea()
                
                LinearGradient(colors: [.clear, .black.opacity(0.9), .black, .black], startPoint: .top, endPoint: .bottom)
                    .frame(width: geo.size.width, height: geo.size.height * 2)
                    .offset(y: shadowOffset)
                    .ignoresSafeArea()
                    .zIndex(10)
                
                VStack {
                    Spacer()
                    Text(typedText)
                        .font(.system(size: 16, weight: .bold, design: .monospaced))
                        .foregroundColor(.white.opacity(0.9)).italic()
                        .padding(.bottom, geo.size.height * 0.20)
                }
                .frame(width: geo.size.width, height: geo.size.height)
                .zIndex(11)
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .onAppear {
                shadowOffset = geo.size.height * 1.5
                withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true)) { isBreathing = true; floatY = -20 }
                withAnimation(.easeInOut(duration: 3.0).repeatForever(autoreverses: true)) { beamPulse = 0.7 }
                particlesActive = true
            }
            .onReceive(timer) { _ in
                if manager.state == .training {
                    if manager.timeRemaining > 0 {
                        manager.timeRemaining -= 1
                    } else if !isTimerFinished {
                        withAnimation(.easeOut(duration: 0.5)) { isTimerFinished = true }
                        UINotificationFeedbackGenerator().notificationOccurred(.success)
                        AudioServicesPlaySystemSound(1054)
                    }
                }
            }
        }
    }
    
    private func startCinematicSequence(geo: GeometryProxy) {
        isTransitioning = true
        particlesActive = false
        isHolding = false
        UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        
        withAnimation(.easeIn(duration: 0.2)) { beamWidth = 0; floatY = 0 }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            shockwaveOpacity = 1.0
            withAnimation(.easeOut(duration: 0.8)) { shockwaveScale = 40.0; shockwaveOpacity = 0.0 }
            withAnimation(.easeOut(duration: 1.0)) { sceneDarkness = 0.6 }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            withAnimation(.easeInOut(duration: 3.5)) { shadowOffset = geo.size.height * 0.1 }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.5) { typeWriterText("...Something approaches.") }
        DispatchQueue.main.asyncAfter(deadline: .now() + 9.0) { manager.completeTraining() }
    }
    
    private func typeWriterText(_ text: String) {
        for (index, character) in text.enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08 * Double(index)) {
                typedText.append(character)
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            }
        }
    }
    
    private func timeString(from totalSeconds: Int) -> String {
        let minutes = totalSeconds / 60
        let seconds = totalSeconds % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

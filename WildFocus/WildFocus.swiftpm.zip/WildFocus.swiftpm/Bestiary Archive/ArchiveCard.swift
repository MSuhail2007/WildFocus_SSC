import SwiftUI

struct ArchiveCard: View {
    let imageName: String
    let name: String
    let unlockLevel: Int
    let isUnlocked: Bool
    let color: Color
    
    var body: some View {
        VStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 15)
                    .fill(Color.black.opacity(0.6))
                    .aspectRatio(1, contentMode: .fit)
                    .overlay(RoundedRectangle(cornerRadius: 15).stroke(isUnlocked ? color.opacity(0.4) : Color.white.opacity(0.1), lineWidth: 2))
                    .shadow(color: isUnlocked ? color.opacity(0.3) : .clear, radius: 10)
                
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .padding(15)
                    .colorMultiply(isUnlocked ? .white : .black)
                    .brightness(isUnlocked ? 0 : -1.0)
                    .opacity(isUnlocked ? 1.0 : 0.4)
                
                if !isUnlocked {
                    Image(systemName: "lock.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.gray.opacity(0.5))
                }
            }
            
            VStack(spacing: 2) {
                Text(name)
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundColor(isUnlocked ? .white : .gray)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                
                Text(isUnlocked ? "UNLOCKED" : "REACH LVL \(unlockLevel)")
                    .font(.system(size: 8, weight: .bold, design: .rounded))
                    .foregroundColor(isUnlocked ? color : .red.opacity(0.6))
            }
        }
    }
}

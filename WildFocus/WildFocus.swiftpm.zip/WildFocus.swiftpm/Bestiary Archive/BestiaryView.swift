import SwiftUI

struct BestiaryView: View {
    @ObservedObject var manager: GameManager
    
    let baseEnemies = [
        ("wild_spore", "Spore Minion", 1),
        ("wild_spider", "Venom Spider", 5),
        ("wild_bat", "Cave Bat", 10),
        ("wild_scorpion", "Desert Scorpion", 15),
        ("wild_condor", "Roc Condor", 20),
        ("wild_grizzly", "Grizzly Boss", 30)
    ]
    
    let eliteEnemies = [
        ("enemy_spore", "Elite Spore", 1),
        ("enemy_spider", "Elite Spider", 5),
        ("enemy_bat", "Elite Bat", 10),
        ("enemy_scorpion", "Elite Scorpion", 15),
        ("enemy_condor", "Elite Condor", 20),
        ("enemy_grizzly", "Elite Grizzly", 30)
    ]
    
    let columns = [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]
    
    var body: some View {
        ZStack {
            Color(white: 0.05).ignoresSafeArea()
            
            VStack {
                HStack {
                    Text("ARCHIVE")
                        .font(.system(size: 24, weight: .black, design: .rounded))
                        .foregroundColor(.white)
                        .tracking(2)
                    Spacer()
                    Button(action: { manager.closeBestiary() }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 28))
                            .foregroundColor(.gray)
                    }
                }
                .padding()
                
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 20) {
                        
                        Text("WILDERNESS THREATS")
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundColor(.gray)
                            .tracking(1)
                            .padding(.horizontal)
                        
                        LazyVGrid(columns: columns, spacing: 15) {
                            ForEach(baseEnemies, id: \.0) { enemy in
                                ArchiveCard(
                                    imageName: enemy.0,
                                    name: enemy.1,
                                    unlockLevel: enemy.2,
                                    isUnlocked: manager.highestLevelReached >= enemy.2 || manager.ascensionLevel >= 1,
                                    color: .cyan
                                )
                            }
                        }
                        .padding(.horizontal)
                        
                        Text("ELITE VARIANTS (RANDOM ENCOUNTERS)")
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundColor(.purple)
                            .tracking(1)
                            .padding(.horizontal)
                            .padding(.top, 15)
                        
                        LazyVGrid(columns: columns, spacing: 15) {
                            ForEach(eliteEnemies, id: \.0) { enemy in
                                ArchiveCard(
                                    imageName: enemy.0,
                                    name: enemy.1,
                                    unlockLevel: enemy.2,
                                    isUnlocked: manager.highestLevelReached >= enemy.2 || manager.ascensionLevel >= 1,
                                    color: .purple
                                )
                            }
                        }
                        .padding(.horizontal)
                        
                    }
                    .padding(.bottom, 40)
                }
            }
        }
    }
}

import SwiftUI

struct RewardsPopup: View {
    @ObservedObject var manager: GameManager
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.opacity(0.85).ignoresSafeArea()
                
                VStack(spacing: geo.size.height > 800 ? 40 : 30) {
                    Image(systemName: manager.didFlee ? "figure.run" : (manager.didWin ? "crown.fill" : "skull.fill"))
                        .font(.system(size: geo.size.height > 800 ? 100 : 80))
                        .foregroundColor(manager.didFlee ? .gray : (manager.didWin ? .yellow : .red))
                        .shadow(color: manager.didFlee ? .gray.opacity(0.6) : (manager.didWin ? .yellow.opacity(0.6) : .red.opacity(0.6)), radius: 30)
                    
                    Text(manager.didFlee ? "ESCAPED" : (manager.didWin ? "VICTORY" : "DEFEAT"))
                        .font(.system(size: geo.size.height > 800 ? 70 : 50, weight: .black, design: .rounded))
                        .foregroundColor(.white)
                        .tracking(5)
                    
                    VStack(spacing: 15) {
                        Text("+\(manager.lastCoinsGained) COINS")
                            .font(.system(size: geo.size.height > 800 ? 50 : 40, weight: .black, design: .rounded))
                            .foregroundColor(manager.didFlee && manager.lastCoinsGained == 0 ? .gray : (manager.didWin || manager.didFlee ? .yellow : .red))
                        
                        Text(manager.didFlee ? (manager.lastCoinsGained > 0 ? "SURVIVAL BONUS" : "You fled from a weak enemy.") : (manager.didWin ? "XP GATHERED" : "Your pet was overwhelmed and fled back to camp."))
                            .font(.system(size: geo.size.height > 800 ? 20 : 16, weight: .bold))
                            .multilineTextAlignment(.center)
                            .foregroundColor(.gray)
                    }
                    .frame(maxWidth: 500)
                    .padding(.horizontal, 40)
                    
                    Button(action: { manager.returnToCamp() }) {
                        Text("RETURN TO CAMP")
                            .font(.system(size: 18, weight: .black, design: .rounded))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 22)
                            .background(manager.didFlee ? LinearGradient(colors: [.gray, .white], startPoint: .top, endPoint: .bottom) : (manager.didWin ? LinearGradient(colors: [.yellow, .orange], startPoint: .top, endPoint: .bottom) : LinearGradient(colors: [.gray, .white], startPoint: .top, endPoint: .bottom)))
                            .cornerRadius(20)
                            .shadow(color: manager.didFlee ? .white.opacity(0.2) : (manager.didWin ? .yellow.opacity(0.4) : .white.opacity(0.2)), radius: 15, y: 10)
                    }
                    .frame(maxWidth: 500)
                    .padding(.horizontal, 40)
                    .padding(.top, 20)
                }
                .frame(width: geo.size.width, height: geo.size.height)
            }
        }
    }
}

import SwiftUI

struct EncounterPopup: View {
    @ObservedObject var manager: GameManager
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.opacity(0.85).ignoresSafeArea()
                
                VStack(spacing: 40) {
                    VStack(spacing: 15) {
                        Image(systemName: "sensor.tag.radiowaves.forward")
                            .font(.system(size: 35, weight: .light))
                            .foregroundColor(.red)
                            .shadow(color: .red.opacity(0.8), radius: 10)
                        
                        Text("ANOMALY DETECTED")
                            .font(.system(size: 20, weight: .black, design: .rounded))
                            .foregroundColor(.white)
                            .tracking(8)
                            .shadow(color: .red.opacity(0.5), radius: 10)
                    }
                    .padding(.top, geo.safeAreaInsets.top > 0 ? geo.safeAreaInsets.top : 40)
                    
                    ZStack {
                        RoundedRectangle(cornerRadius: 30)
                            .fill(Color(white: 0.05))
                            .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.1), lineWidth: 1))
                            .shadow(color: .black.opacity(0.8), radius: 30, y: 20)
                        
                        HStack(spacing: 0) {
                            VStack(spacing: 12) {
                                Image(manager.currentPetImage)
                                    .resizable().scaledToFit().frame(height: 90)
                                    .colorMultiply(manager.currentPetColor == .cyan ? .white : manager.currentPetColor)
                                    .shadow(color: manager.currentPetColor.opacity(0.5), radius: 15)
                                
                                Text("POWER")
                                    .font(.system(size: 10, weight: .bold)).foregroundColor(manager.currentPetColor).tracking(2)
                                Text("\(manager.petPower)")
                                    .font(.system(size: 32, weight: .black, design: .rounded)).foregroundColor(.white)
                            }
                            .frame(maxWidth: .infinity)
                            
                            ZStack {
                                Circle().fill(Color.black).frame(width: 50, height: 50)
                                    .shadow(color: .red.opacity(0.8), radius: 15)
                                Text("VS").font(.system(size: 18, weight: .black, design: .rounded)).foregroundColor(.red).italic()
                            }
                            .zIndex(2)
                            
                            VStack(spacing: 12) {
                                Image(manager.currentEnemyImage)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 75)
                                    .colorMultiply(manager.currentEnemyColor)
                                    .shadow(color: manager.currentEnemyColor.opacity(0.5), radius: 15)
                                
                                Text(manager.currentEnemyTitle.uppercased())
                                    .font(.system(size: 10, weight: .bold))
                                    .foregroundColor(manager.currentEnemyColor)
                                    .tracking(1)
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.5)
                                
                                Text("\(manager.currentEnemyPower)")
                                    .font(.system(size: 32, weight: .black, design: .rounded)).foregroundColor(.white)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.horizontal, 5)
                        }
                        .padding(.vertical, 30)
                    }
                    .frame(height: 220)
                    .frame(maxWidth: 500)
                    .padding(.horizontal, 30)
                    
                    Spacer()
                    
                    HStack(spacing: 20) {
                        Button(action: { manager.fleeEncounter() }) {
                            Text("FLEE")
                                .font(.system(size: 14, weight: .bold, design: .rounded))
                                .foregroundColor(.gray)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 22)
                                .background(Color.white.opacity(0.05))
                                .clipShape(Capsule())
                        }
                        
                        Button(action: {
                            let impact = UIImpactFeedbackGenerator(style: .heavy)
                            impact.impactOccurred()
                            manager.fightEnemy()
                        }) {
                            HStack {
                                Text("ENGAGE")
                                Image(systemName: "bolt.fill")
                            }
                            .font(.system(size: 16, weight: .black, design: .rounded))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 22)
                            .background(LinearGradient(colors: [.red, Color(red: 0.6, green: 0, blue: 0)], startPoint: .topLeading, endPoint: .bottomTrailing))
                            .clipShape(Capsule())
                            .shadow(color: .red.opacity(0.6), radius: 15, y: 5)
                        }
                    }
                    .frame(maxWidth: 500)
                    .padding(.horizontal, 30)
                    .padding(.bottom, 60)
                }
                .frame(width: geo.size.width, height: geo.size.height)
            }
        }
    }
}

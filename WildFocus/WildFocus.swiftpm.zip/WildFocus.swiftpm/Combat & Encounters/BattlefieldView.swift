import SwiftUI

struct BattlefieldView: View {
    @ObservedObject var manager: GameManager
    
    @State private var isBreathing = false
    @State private var foxDashOffset: CGFloat = 0
    @State private var enemyShake: CGFloat = 0
    @State private var flashOpacity: Double = 0.0
    
    @State private var enemyDamageTint = false
    @State private var hasBeenHit = false
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Image(manager.currentBiome.imageName)
                    .resizable()
                    .scaledToFill()
                    .frame(width: geo.size.width, height: geo.size.height)
                    .ignoresSafeArea()
                    .overlay(Color.black.opacity(0.35))
                
                if manager.state != .training {
                    VStack {
                        Color.black.frame(height: geo.size.height * 0.12).transition(.move(edge: .top))
                        Spacer()
                        Color.black.frame(height: geo.size.height * 0.12).transition(.move(edge: .bottom))
                    }
                    .ignoresSafeArea()
                    .zIndex(1)
                }
                
                Color.white.opacity(flashOpacity).ignoresSafeArea().blendMode(.screen).zIndex(2)
                
                VStack {
                    Spacer()
                    
                    HStack(spacing: geo.size.width > 600 ? 80 : 30) {
                        // 1. PET ON THE LEFT
                        Image(manager.currentPetImage)
                            .resizable()
                            .scaledToFit()
                            .frame(height: geo.size.height > 800 ? 250 : 170)
                            .offset(x: foxDashOffset)
                            .scaleEffect(x: 1.0, y: isBreathing ? 1.03 : 0.98, anchor: .bottom)
                            .offset(y: isBreathing ? -2 : 2)
                            .colorMultiply(manager.currentPetColor == .cyan ? .white : manager.currentPetColor)
                            .shadow(color: manager.currentPetColor.opacity(0.6), radius: geo.size.height > 800 ? 30 : 20, y: 10)
                            .zIndex(2)
                        
                        if manager.state == .enemyAppearing || manager.state == .battling || manager.state == .rewards {
                            Image(manager.currentEnemyImage)
                                .resizable()
                                .scaledToFit()
                                .frame(height: geo.size.height > 800 ? 220 : 150)
                                .offset(x: enemyShake)
                                .scaleEffect(isBreathing ? 1.02 : 0.98)
                                .offset(y: isBreathing ? -3 : 3)
                                .rotationEffect(.degrees(hasBeenHit ? -15 : 0))
                                .offset(x: hasBeenHit ? 20 : 0, y: hasBeenHit ? 10 : 0)
                                .colorMultiply(hasBeenHit ? .gray : (enemyDamageTint ? .red : manager.currentEnemyColor))
                                .brightness(hasBeenHit ? -0.2 : 0)
                                .shadow(color: manager.currentEnemyColor.opacity(0.6), radius: geo.size.height > 800 ? 30 : 20, y: 10)
                                .transition(.move(edge: .trailing).combined(with: .opacity))
                        }
                    }
                    .padding(.bottom, geo.size.height * 0.15)
                }
                .frame(width: geo.size.width, height: geo.size.height)
            }
            .onAppear {
                withAnimation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true)) { isBreathing = true }
            }
            .onChange(of: manager.state) { newState in
                if newState == .battling { triggerCombatSequence(width: geo.size.width) }
                else if newState == .training || newState == .camp { hasBeenHit = false }
            }
        }
    }
    
    private func triggerCombatSequence(width: CGFloat) {
        withAnimation(.easeIn(duration: 0.2)) { foxDashOffset = width * 0.3 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            
            withAnimation(.easeOut(duration: 0.1)) { enemyDamageTint = true }
            
            flashOpacity = 1.0
            withAnimation(.easeOut(duration: 0.5)) { flashOpacity = 0.0 }
            withAnimation(.spring(response: 0.2, dampingFraction: 0.2)) { enemyShake = 20 }
            
            UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                withAnimation {
                    enemyShake = 0
                    enemyDamageTint = false
                    if manager.petPower >= manager.currentEnemyPower { hasBeenHit = true }
                }
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            withAnimation(.easeOut(duration: 0.3)) { foxDashOffset = 0 }
        }
    }
}

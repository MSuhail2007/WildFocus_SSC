import SwiftUI

struct HeartParticle: Identifiable {
    let id = UUID()
    let xOffset = CGFloat.random(in: -40...40)
    let yOffset = CGFloat.random(in: -80...(-40))
}

struct CampView: View {
    @ObservedObject var manager: GameManager
    
    @State private var isBreathing = false
    @State private var showUpgradeGlow = false
    @State private var evolutionFlash = 0.0
    @State private var oldLevel = 1
    
    @AppStorage("hasHatchedStarter") private var hasHatchedStarter = false
    @State private var showStats = false
    @State private var tapHearts: [HeartParticle] = []
    
    @State private var pulseDeploy = false
    @State private var particles = (0..<20).map { _ in Particle() }
    @State private var animateParticles = false
    
    var upgradeCost: Int { manager.petLevel * 15 }
    
    var body: some View {
        GeometryReader { geo in
            let isPad = geo.size.width > 600
            
            ZStack {
                Image(manager.currentBiome.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()
                    .overlay(Color.black.opacity(0.4))
                
                ForEach(particles) { particle in
                    Circle()
                        .fill(manager.currentPetColor.opacity(Double.random(in: 0.1...0.6)))
                        .frame(width: particle.randomSize * (isPad ? 1.5 : 1.0), height: particle.randomSize * (isPad ? 1.5 : 1.0))
                        .offset(x: particle.randomX, y: animateParticles ? -geo.size.height : geo.size.height / 2)
                        .blur(radius: isPad ? 3 : 2)
                        .animation(Animation.linear(duration: particle.duration).repeatForever(autoreverses: false).delay(particle.delay), value: animateParticles)
                }
                
                Color.white.opacity(evolutionFlash)
                    .ignoresSafeArea()
                    .blendMode(.screen)
                    .zIndex(10)
                
                if hasHatchedStarter {
                    VStack {
                        HStack(alignment: .center) {
                            HStack(spacing: isPad ? 14 : 10) {
                                ZStack {
                                    Circle()
                                        .fill(Color.black.opacity(0.8))
                                        .frame(width: isPad ? 50 : 40, height: isPad ? 50 : 40)
                                    Text(manager.petLevel >= 30 ? "MAX" : "\(manager.petLevel)")
                                        .font(.custom("AvenirNext-Heavy", size: isPad ? 18 : 14))
                                        .foregroundColor(.white)
                                }
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("\(manager.petName.uppercased())")
                                        .font(.custom("AvenirNext-Heavy", size: isPad ? 12 : 10))
                                        .foregroundColor(manager.currentPetColor)
                                        .lineLimit(1)
                                    
                                    GeometryReader { xpGeo in
                                        ZStack(alignment: .leading) {
                                            Capsule().fill(Color.black.opacity(0.6))
                                            Capsule()
                                                .fill(manager.currentPetColor)
                                                .frame(width: max(0, xpGeo.size.width * CGFloat(manager.currentXP) / CGFloat(manager.xpNeededForNextLevel)))
                                                .shadow(color: manager.currentPetColor.opacity(0.8), radius: 5)
                                        }
                                    }
                                    .frame(width: isPad ? 180 : 110, height: isPad ? 10 : 8)
                                }
                            }
                            .padding(isPad ? 10 : 8)
                            .background(.ultraThinMaterial)
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(Color.white.opacity(0.2), lineWidth: 1))
                            
                            Spacer(minLength: 5)
                            
                            HStack(spacing: 8) {
                                Button(action: {
                                    let impact = UIImpactFeedbackGenerator(style: .medium)
                                    impact.impactOccurred()
                                    showStats = true
                                }) {
                                    Image(systemName: "chart.bar.xaxis")
                                        .font(.system(size: isPad ? 16 : 12, weight: .bold))
                                        .foregroundColor(.white)
                                        .frame(width: isPad ? 44 : 36, height: isPad ? 44 : 36)
                                        .background(.ultraThinMaterial)
                                        .clipShape(Circle())
                                        .overlay(Circle().stroke(Color.white.opacity(0.2), lineWidth: 1))
                                }
                                
                                HStack(spacing: 6) {
                                    Text("\(manager.coins)")
                                        .font(.custom("AvenirNext-Heavy", size: isPad ? 20 : 16))
                                        .foregroundColor(.yellow)
                                    Image(systemName: "circle.grid.hex.fill")
                                        .font(.system(size: isPad ? 16 : 12))
                                        .foregroundColor(.yellow)
                                }
                                .padding(.horizontal, isPad ? 16 : 12)
                                .padding(.vertical, isPad ? 12 : 10)
                                .background(.ultraThinMaterial)
                                .clipShape(Capsule())
                                .overlay(Capsule().stroke(Color.yellow.opacity(0.3), lineWidth: 1))
                            }
                        }
                        .padding(.horizontal, isPad ? 40 : 20)
                        .padding(.top, geo.safeAreaInsets.top + (isPad ? 20 : 10))
                        
                        Spacer()
                        
                        ZStack {
                            Text("READY FOR COMBAT")
                                .font(.custom("AvenirNext-Heavy", size: isPad ? 14 : 10))
                                .foregroundColor(.white)
                                .padding(.horizontal, isPad ? 18 : 12).padding(.vertical, isPad ? 10 : 6)
                                .background(Color.black.opacity(0.6))
                                .clipShape(Capsule())
                                .offset(y: isPad ? -200 : -140)
                                .opacity(isBreathing ? 1.0 : 0.6)
                            
                            Circle()
                                .fill(showUpgradeGlow ? manager.currentPetColor : Color.clear)
                                .frame(width: min(geo.size.width * 0.8, 500))
                                .blur(radius: isPad ? 80 : 50)
                                .opacity(showUpgradeGlow ? 0.6 : 0)
                            
                            Image(manager.currentPetImage)
                                .resizable()
                                .scaledToFit()
                                .frame(width: min(geo.size.width * 0.75, 450))
                                .scaleEffect(x: 1.0, y: isBreathing ? 1.03 : 0.98, anchor: .bottom)
                                .offset(y: isBreathing ? -3 : 3)
                                .scaleEffect(showUpgradeGlow ? 1.15 : 1.0)
                                .shadow(color: manager.currentPetColor.opacity(0.5), radius: isPad ? 40 : 25, y: isPad ? 25 : 15)
                                .onTapGesture { handlePetTap() }
                            
                            ForEach(tapHearts) { heart in
                                Image(systemName: "heart.fill")
                                    .font(.system(size: isPad ? 40 : 30))
                                    .foregroundColor(manager.currentPetColor)
                                    .shadow(color: manager.currentPetColor.opacity(0.6), radius: 10)
                                    .offset(x: heart.xOffset, y: heart.yOffset)
                                    .transition(.asymmetric(insertion: .scale.combined(with: .opacity), removal: .opacity.combined(with: .move(edge: .top))))
                            }
                            
                            if showUpgradeGlow {
                                Text("+50 XP")
                                    .font(.custom("AvenirNext-Heavy", size: isPad ? 50 : 35))
                                    .foregroundColor(manager.currentPetColor)
                                    .shadow(color: .black.opacity(0.8), radius: 5, x: 0, y: 3)
                                    .offset(y: isPad ? -250 : -180)
                                    .transition(.move(edge: .bottom).combined(with: .opacity))
                            }
                        }
                        
                        Spacer()
                        
                        HStack(spacing: isPad ? 20 : 12) {
                            Button(action: {
                                let impact = UIImpactFeedbackGenerator(style: .medium)
                                impact.impactOccurred()
                                manager.openBestiary()
                            }) {
                                VStack(spacing: 6) {
                                    Image(systemName: "book.closed.fill").font(.system(size: isPad ? 30 : 24))
                                    Text("ARCHIVE").font(.custom("AvenirNext-Heavy", size: isPad ? 12 : 10))
                                }
                                .foregroundColor(.white)
                                .frame(width: isPad ? 100 : 80, height: isPad ? 100 : 80)
                                .background(Color.black.opacity(0.7))
                                .cornerRadius(isPad ? 25 : 20)
                                .overlay(RoundedRectangle(cornerRadius: isPad ? 25 : 20).stroke(Color.white.opacity(0.2), lineWidth: 1))
                            }
                            
                            Button(action: {
                                if manager.coins >= upgradeCost {
                                    let impact = UIImpactFeedbackGenerator(style: .heavy)
                                    impact.impactOccurred()
                                    manager.coins -= upgradeCost
                                    withAnimation(.spring(response: 0.3, dampingFraction: 0.5)) { showUpgradeGlow = true }
                                    manager.gainXP(amount: 50)
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                        withAnimation(.easeOut(duration: 0.3)) { showUpgradeGlow = false }
                                    }
                                } else {
                                    UINotificationFeedbackGenerator().notificationOccurred(.error)
                                }
                            }) {
                                VStack(spacing: 4) {
                                    Image(systemName: "arrow.up.circle.fill").font(.system(size: isPad ? 30 : 24))
                                    Text("TRAIN").font(.custom("AvenirNext-Heavy", size: isPad ? 14 : 12))
                                    
                                    if manager.coins >= upgradeCost {
                                        Text("\(upgradeCost) COINS").font(.custom("AvenirNext-Bold", size: isPad ? 10 : 9)).foregroundColor(.yellow)
                                    } else {
                                        Text("NEED \(upgradeCost)").font(.custom("AvenirNext-Bold", size: isPad ? 10 : 9)).foregroundColor(Color(red: 1.0, green: 0.4, blue: 0.4))
                                    }
                                }
                                .foregroundColor(manager.coins >= upgradeCost ? .white : .gray)
                                .frame(width: isPad ? 100 : 80, height: isPad ? 100 : 80)
                                .background(manager.coins >= upgradeCost ? Color(red: 0.2, green: 0.2, blue: 0.3) : Color.black.opacity(0.6))
                                .cornerRadius(isPad ? 25 : 20)
                            }
                            
                            Button(action: {
                                manager.startSetup()
                            }) {
                                HStack(spacing: 10) {
                                    Text("DEPLOY").font(.custom("AvenirNext-Heavy", size: isPad ? 26 : 20))
                                    Image(systemName: "chevron.right.2").font(.system(size: isPad ? 24 : 18, weight: .bold))
                                }
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .frame(height: isPad ? 100 : 80)
                                .background(LinearGradient(colors: [.red, .orange], startPoint: .leading, endPoint: .trailing))
                                .cornerRadius(isPad ? 50 : 40)
                                .shadow(color: .red.opacity(pulseDeploy ? 0.8 : 0.4), radius: pulseDeploy ? 20 : 10, y: 8)
                            }
                        }
                        .frame(maxWidth: 600)
                        .padding(.horizontal, isPad ? 40 : 20)
                        .padding(.bottom, isPad ? 60 : 40)
                    }
                } else {
                    OnboardingView(manager: manager, onHatch: triggerHatchCinematic)
                        .transition(.opacity)
                }
            }
        }
        .sheet(isPresented: $showStats) {
            StatsView(manager: manager)
        }
        .onAppear {
            oldLevel = manager.petLevel
            animateParticles = true
            withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true)) { isBreathing = true }
            withAnimation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true)) { pulseDeploy = true }
        }
        .onChange(of: manager.petLevel) { newLevel in
            if newLevel > oldLevel && hasHatchedStarter {
                let impact = UIImpactFeedbackGenerator(style: .heavy)
                impact.impactOccurred()
                withAnimation(.easeIn(duration: 0.1)) { evolutionFlash = 1.0 }
                withAnimation(.easeOut(duration: 1.5).delay(0.1)) { evolutionFlash = 0.0 }
                oldLevel = newLevel
            }
        }
    }
    
    private func handlePetTap() {
        let impact = UIImpactFeedbackGenerator(style: .light)
        impact.impactOccurred()
        
        let newHeart = HeartParticle()
        withAnimation(.easeOut(duration: 0.3)) { tapHearts.append(newHeart) }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            withAnimation(.easeIn(duration: 0.3)) { tapHearts.removeAll { $0.id == newHeart.id } }
        }
    }
    
    private func triggerHatchCinematic() {
        let success = UINotificationFeedbackGenerator()
        success.notificationOccurred(.success)
        withAnimation(.easeIn(duration: 0.1)) { evolutionFlash = 1.0 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            hasHatchedStarter = true
            withAnimation(.easeOut(duration: 1.5)) { evolutionFlash = 0.0 }
        }
    }
}

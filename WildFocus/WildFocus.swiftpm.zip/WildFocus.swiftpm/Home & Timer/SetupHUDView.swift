import SwiftUI

struct SetupHUDView: View {
    @ObservedObject var manager: GameManager
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack(spacing: 30) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("MISSION CALIBRATION")
                            .font(.custom("AvenirNext-Heavy", size: 14))
                            .foregroundColor(.orange)
                            .tracking(2)
                        Text("SELECT HUNT DURATION")
                            .font(.custom("AvenirNext-Bold", size: 12))
                            .foregroundColor(.gray)
                    }
                    Spacer()
                    
                    Button(action: {
                        let impact = UIImpactFeedbackGenerator(style: .light)
                        impact.impactOccurred()
                        manager.cancelSetup()
                    }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 40, height: 40)
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                    }
                }
                
                ZStack {
                    Circle()
                        .stroke(Color.orange.opacity(0.2), lineWidth: 2)
                        .frame(width: 180, height: 180)
                    Circle()
                        .stroke(Color.orange.opacity(0.5), style: StrokeStyle(lineWidth: 1, dash: [5, 5]))
                        .frame(width: 160, height: 160)
                    
                    VStack(spacing: -5) {
                        Text("\(Int(manager.selectedMinutes))")
                            .font(.custom("AvenirNext-Heavy", size: 80))
                            .foregroundColor(.white)
                            .shadow(color: .orange.opacity(0.6), radius: 10, y: 5)
                        Text("MINUTES")
                            .font(.custom("AvenirNext-Heavy", size: 16))
                            .foregroundColor(.orange)
                            .tracking(2)
                    }
                }

                VStack(spacing: 10) {
                    Slider(value: $manager.selectedMinutes, in: 5...120, step: 5)
                        .accentColor(.orange)
                    
                    HStack {
                        Text("5 MIN").font(.custom("AvenirNext-Bold", size: 10)).foregroundColor(.gray)
                        Spacer()
                        Text("120 MIN").font(.custom("AvenirNext-Bold", size: 10)).foregroundColor(.gray)
                    }
                }
                .padding(.horizontal, 10)
                

                Button(action: {
                    let impact = UIImpactFeedbackGenerator(style: .heavy)
                    impact.impactOccurred()
                    manager.startTraining()
                }) {
                    HStack(spacing: 12) {
                        Image(systemName: "scope")
                            .font(.system(size: 22, weight: .bold))
                        Text("ENGAGE DEPLOYMENT")
                            .font(.custom("AvenirNext-Heavy", size: 18))
                    }
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 22)
                    .background(LinearGradient(colors: [.yellow, .orange], startPoint: .top, endPoint: .bottom))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .shadow(color: .orange.opacity(0.6), radius: 20, y: 10)
                }
                .padding(.top, 10)
            }
            .padding(35)
            .background(
                ZStack {
                    Color(red: 0.05, green: 0.05, blue: 0.08).opacity(0.95)
                    // Grid lines for map effect
                    Image(systemName: "squareshape.split.3x3")
                        .resizable()
                        .opacity(0.02)
                        .foregroundColor(.white)
                }
            )
            .clipShape(UnevenRoundedRectangle(topLeadingRadius: 40, topTrailingRadius: 40))
            .overlay(UnevenRoundedRectangle(topLeadingRadius: 40, topTrailingRadius: 40).stroke(Color.orange.opacity(0.3), lineWidth: 2))
            .shadow(color: .black.opacity(0.8), radius: 30, y: -10)
        }
        .ignoresSafeArea(edges: .bottom)
    }
}

import SwiftUI

struct StatsView: View {
    @ObservedObject var manager: GameManager
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ZStack {
            Color(white: 0.05).ignoresSafeArea()
            
            VStack(spacing: 30) {
                HStack {
                    Text("LIFETIME STATS")
                        .font(.custom("AvenirNext-Heavy", size: 24))
                        .foregroundColor(.white)
                        .tracking(2)
                    Spacer()
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 28))
                            .foregroundColor(.gray)
                    }
                }
                .padding()
                
                ScrollView {
                    VStack(spacing: 20) {
                        StatCard(
                            title: "TOTAL FOCUS TIME",
                            value: "\(manager.totalFocusTimeMinutes) MIN",
                            icon: "flame.fill",
                            color: .orange
                        )
                        
                        StatCard(
                            title: "MONSTERS DEFEATED",
                            value: "\(manager.totalMonstersDefeated)",
                            icon: "pawprint.fill",
                            color: .red
                        )
                        
                        StatCard(
                            title: "SESSIONS COMPLETED",
                            value: "\(manager.totalSessionsCompleted)",
                            icon: "clock.fill",
                            color: manager.currentPetColor
                        )
                    }
                    .padding(.horizontal)
                }
                
                Spacer()
            }
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        HStack(spacing: 20) {
            ZStack {
                Circle().fill(color.opacity(0.2)).frame(width: 60, height: 60)
                Image(systemName: icon).font(.system(size: 24)).foregroundColor(color)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.custom("AvenirNext-Bold", size: 12))
                    .foregroundColor(.gray)
                    .tracking(1)
                Text(value)
                    .font(.custom("AvenirNext-Heavy", size: 28))
                    .foregroundColor(.white)
            }
            Spacer()
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(20)
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.1), lineWidth: 1))
    }
}
